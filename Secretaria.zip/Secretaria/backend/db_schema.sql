-- Esquema inicial para MySQL
CREATE DATABASE IF NOT EXISTS secretaria_db;
USE secretaria_db;

-- Usuários (administradores e secretarias)
CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(200) NOT NULL,
  email VARCHAR(200) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('admin','secretaria') NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Alunos
CREATE TABLE IF NOT EXISTS students (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(200) NOT NULL,
  cpf VARCHAR(14) NOT NULL UNIQUE,
  birthdate DATE NOT NULL,
  phone VARCHAR(30),
  address VARCHAR(300),
  email VARCHAR(200),
  status ENUM('ativo','inativo') DEFAULT 'ativo',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Cursos e Turmas (turmas referem-se a instâncias do curso)
CREATE TABLE IF NOT EXISTS classes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL UNIQUE, -- ex: DDS-7
  course VARCHAR(200) NOT NULL,
  shift ENUM('matutino','vespertino','noturno') NOT NULL,
  year_semester VARCHAR(50) NOT NULL, -- ex: 2025/1
  max_vacancies INT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Matrículas
CREATE TABLE IF NOT EXISTS enrollments (
  id INT AUTO_INCREMENT PRIMARY KEY,
  student_id INT NOT NULL,
  class_id INT NOT NULL,
  enroll_date DATE NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uniq_student_class (student_id, class_id),
  FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
  FOREIGN KEY (class_id) REFERENCES classes(id) ON DELETE CASCADE
);

-- Notas e frequência por aluno em cada turma/disciplina
CREATE TABLE IF NOT EXISTS grades (
  id INT AUTO_INCREMENT PRIMARY KEY,
  enrollment_id INT NOT NULL,
  discipline VARCHAR(200),
  score DECIMAL(4,2) CHECK (score >= 0 AND score <= 10),
  attendance_percent DECIMAL(5,2) CHECK (attendance_percent >= 0 AND attendance_percent <= 100),
  final_status ENUM('aprovado','reprovado','cursando'),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (enrollment_id) REFERENCES enrollments(id) ON DELETE CASCADE
);

-- Solicitações/Atendimentos
CREATE TABLE IF NOT EXISTS requests (
  id INT AUTO_INCREMENT PRIMARY KEY,
  student_id INT NOT NULL,
  type VARCHAR(200) NOT NULL,
  date DATE NOT NULL,
  status ENUM('aberto','em andamento','concluido') DEFAULT 'aberto',
  note TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
);

-- Índices básicos
CREATE INDEX idx_students_status ON students(status);
CREATE INDEX idx_requests_status ON requests(status);
