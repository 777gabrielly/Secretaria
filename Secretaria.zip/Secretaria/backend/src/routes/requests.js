const express = require('express');
const router = express.Router();
const pool = require('../db');
const { body, validationResult } = require('express-validator');
const auth = require('../middleware/auth');

// Registrar atendimento/solicitação
router.post('/', auth(['admin','secretaria']), [
  body('student_id').isInt(),
  body('type').notEmpty(),
  body('date').isISO8601(),
  body('status').isIn(['aberto','em andamento','concluido'])
], async (req, res) => {
  const errors = validationResult(req); if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });
  const { student_id, type, date, status, note } = req.body;
  const [result] = await pool.query('INSERT INTO requests (student_id,type,date,status,note) VALUES (?,?,?,?,?)', [student_id,type,date,status,note || null]);
  res.json({ id: result.insertId, message: 'Solicitação registrada' });
});

// Listar solicitações
router.get('/', auth(), async (req, res) => {
  const [rows] = await pool.query('SELECT r.id, r.student_id, s.name as student_name, r.type, r.date, r.status FROM requests r JOIN students s ON s.id = r.student_id');
  res.json(rows);
});

module.exports = router;
