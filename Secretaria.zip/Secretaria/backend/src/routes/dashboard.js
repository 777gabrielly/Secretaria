const express = require('express');
const router = express.Router();
const pool = require('../db');
const auth = require('../middleware/auth');

router.get('/', auth(), async (req, res) => {
  const [[{ total_active }]] = await pool.query("SELECT SUM(status='ativo') AS total_active FROM students");
  const [[{ open_classes }]] = await pool.query("SELECT COUNT(*) AS open_classes FROM classes");
  const [[{ enrollments_semester }]] = await pool.query("SELECT COUNT(*) AS enrollments_semester FROM enrollments");
  const [[{ requests_open }]] = await pool.query("SELECT COUNT(*) AS requests_open FROM requests WHERE status != 'concluido'");
  res.json({
    total_active: total_active || 0,
    total_classes: open_classes || 0,
    enrollments_semester: enrollments_semester || 0,
    requests_open: requests_open || 0
  });
});

module.exports = router;
