const express = require('express');
const router = express.Router();
const pool = require('../db');
const { body, validationResult } = require('express-validator');
const auth = require('../middleware/auth');

// Listar alunos (com filtro)
router.get('/', auth(), async (req, res) => {
  const [rows] = await pool.query('SELECT id, name, cpf, birthdate, phone, address, email, status FROM students');
  res.json(rows);
});

// Criar aluno
router.post('/', auth(['admin','secretaria']), [
  body('name').notEmpty(),
  body('cpf').notEmpty(),
  body('birthdate').isDate(),
  body('email').isEmail().optional({ nullable: true }),
  body('status').isIn(['ativo','inativo'])
], async (req, res) => {
  const errors = validationResult(req); if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });
  const { name, cpf, birthdate, phone, address, email, status } = req.body;
  // CPF único
  const [exists] = await pool.query('SELECT id FROM students WHERE cpf = ?', [cpf]);
  if (exists.length) return res.status(400).json({ message: 'CPF já cadastrado' });
  const [result] = await pool.query('INSERT INTO students (name,cpf,birthdate,phone,address,email,status) VALUES (?,?,?,?,?,?,?)',
    [name,cpf,birthdate,phone,address,email,status]);
  res.json({ id: result.insertId, name, cpf });
});

// Pegar aluno por id
router.get('/:id', auth(), async (req, res) => {
  const [rows] = await pool.query('SELECT id, name, cpf, birthdate, phone, address, email, status FROM students WHERE id = ?', [req.params.id]);
  if (!rows.length) return res.status(404).json({ message: 'Aluno não encontrado' });
  res.json(rows[0]);
});

// Editar aluno
router.put('/:id', auth(['admin','secretaria']), [
  body('name').optional().notEmpty(),
  body('cpf').optional().notEmpty(),
  body('birthdate').optional().isDate(),
  body('status').optional().isIn(['ativo','inativo'])
], async (req, res) => {
  const id = req.params.id;
  const data = req.body;
  if (data.cpf) {
    const [exists] = await pool.query('SELECT id FROM students WHERE cpf = ? AND id != ?', [data.cpf, id]);
    if (exists.length) return res.status(400).json({ message: 'CPF já cadastrado para outro aluno' });
  }
  const fields = Object.keys(data).map(k => `${k} = ?`).join(', ');
  const values = Object.values(data);
  values.push(id);
  await pool.query(`UPDATE students SET ${fields} WHERE id = ?`, values);
  res.json({ message: 'Aluno atualizado' });
});

module.exports = router;
