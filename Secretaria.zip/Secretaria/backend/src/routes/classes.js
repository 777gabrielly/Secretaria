const express = require('express');
const router = express.Router();
const pool = require('../db');
const { body, validationResult } = require('express-validator');
const auth = require('../middleware/auth');

// Listar turmas
router.get('/', auth(), async (req, res) => {
  const [rows] = await pool.query('SELECT c.id, c.name, c.course, c.shift, c.year_semester, c.max_vacancies, COUNT(e.id) AS enrolled FROM classes c LEFT JOIN enrollments e ON e.class_id = c.id GROUP BY c.id');
  res.json(rows);
});

// Criar turma
router.post('/', auth(['admin','secretaria']), [
  body('name').notEmpty(),
  body('course').notEmpty(),
  body('shift').isIn(['matutino','vespertino','noturno']),
  body('year_semester').notEmpty(),
  body('max_vacancies').isInt({ min: 1 })
], async (req, res) => {
  const errors = validationResult(req); if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });
  const { name, course, shift, year_semester, max_vacancies } = req.body;
  const [exists] = await pool.query('SELECT id FROM classes WHERE name = ?', [name]);
  if (exists.length) return res.status(400).json({ message: 'Nome de turma já existe' });
  const [result] = await pool.query('INSERT INTO classes (name,course,shift,year_semester,max_vacancies) VALUES (?,?,?,?,?)', [name,course,shift,year_semester,max_vacancies]);
  res.json({ id: result.insertId, name });
});

module.exports = router;
