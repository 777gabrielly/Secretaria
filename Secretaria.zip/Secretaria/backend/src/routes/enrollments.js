const express = require('express');
const router = express.Router();
const pool = require('../db');
const { body, validationResult } = require('express-validator');
const auth = require('../middleware/auth');

// Matricular aluno
router.post('/', auth(['admin','secretaria']), [
  body('student_id').isInt(),
  body('class_id').isInt(),
  body('enroll_date').isISO8601()
], async (req, res) => {
  const errors = validationResult(req); if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });
  const { student_id, class_id, enroll_date } = req.body;

  // Verificar aluno ativo
  const [srows] = await pool.query('SELECT status FROM students WHERE id = ?', [student_id]);
  if (!srows.length) return res.status(404).json({ message: 'Aluno não encontrado' });
  if (srows[0].status !== 'ativo') return res.status(400).json({ message: 'Aluno inativo não pode ser matriculado' });

  // Verificar duplicidade na mesma turma
  const [dup] = await pool.query('SELECT id FROM enrollments WHERE student_id = ? AND class_id = ?', [student_id, class_id]);
  if (dup.length) return res.status(400).json({ message: 'Aluno já matriculado nesta turma' });

  // Verificar vagas
  const [[cinfo]] = await pool.query('SELECT max_vacancies, (SELECT COUNT(*) FROM enrollments e WHERE e.class_id = c.id) AS enrolled FROM classes c WHERE c.id = ?', [class_id]);
  if (!cinfo) return res.status(404).json({ message: 'Turma não encontrada' });
  if (cinfo.enrolled >= cinfo.max_vacancies) return res.status(400).json({ message: 'Turma está lotada' });

  const [result] = await pool.query('INSERT INTO enrollments (student_id,class_id,enroll_date) VALUES (?,?,?)', [student_id,class_id,enroll_date]);
  res.json({ id: result.insertId, message: 'Matrícula realizada' });
});

module.exports = router;
